from kafka2delta.config.config import DeltaTableConfig

__all__ = ['DeltaTableConfig']
